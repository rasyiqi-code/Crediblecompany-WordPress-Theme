// File kosong untuk mencegah error 404 pada form.js 

// Script AJAX submit form testimoni Customer Says
jQuery(document).ready(function($) {
    var photoInput = $('#customer_photo');
    var photoPreview = $('#photo-preview');
    var defaultAvatar = photoInput.data('default');

    // Fungsi untuk preview file foto
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                photoPreview.attr('src', e.target.result);
                photoPreview.removeClass('default-preview');
            }
            reader.readAsDataURL(input.files[0]);
        } else {
            photoPreview.attr('src', defaultAvatar);
            photoPreview.addClass('default-preview');
        }
    }
    photoInput.on('change', function() {
        readURL(this);
    });
    $('#customer-says-form').on('reset', function() {
        photoPreview.attr('src', defaultAvatar);
        photoPreview.addClass('default-preview');
    });

    // Fungsi untuk menampilkan modal notifikasi
    function showModal(message) {
        $('.customer-says-modal-message').html(message);
        $('#customer-says-modal').fadeIn();
    }
    // Tutup modal jika klik close
    $('.customer-says-modal-close').on('click', function() {
        $('#customer-says-modal').fadeOut();
    });
    // Tutup modal jika klik di luar konten
    $('#customer-says-modal').on('click', function(e) {
        if ($(e.target).is('#customer-says-modal')) {
            $('#customer-says-modal').fadeOut();
        }
    });

    // Submit form via AJAX
    $('#customer-says-form').on('submit', function(e) {
        e.preventDefault();
        var form = this;
        var formData = new FormData(form);
        formData.append('action', 'customer_says_submit');
        // Kirim AJAX ke WordPress
        $.ajax({
            url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showModal(response.data.message);
                    form.reset();
                } else {
                    showModal(response.data.message);
                }
            },
            error: function(xhr) {
                showModal('Terjadi kesalahan pada server. Silakan coba lagi.');
            }
        });
    });
}); 