<?php
/**
 * Plugin Name:       Customer Says
 * Plugin URI:        https://wordpress.org/plugins/customer-says
 * Description:       A plugin to manage customer testimonials with custom post type support and optional Elementor integration
 * Version:          1.3.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:           Rasyiqi
 * Author URI:        https://crediblemark.com
 * License:          GPL v2 or later
 * License URI:      https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:      customer-says
 * Domain Path:      /languages
 * 
 * Elementor tested up to: 3.18.3
 * Elementor Pro tested up to: 3.18.3
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

// Define plugin constants
define('CUSTOMER_SAYS_VERSION', '1.3.0');
define('CUSTOMER_SAYS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CUSTOMER_SAYS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include files
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/post-type.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/form-handler.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/metabox.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/shortcodes.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/template-functions.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/welcome-notice.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/admin/class-admin-columns.php';
require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/admin/class-bulk-edit.php';

// Initialize Elementor integration if available
function customer_says_elementor_init() {
    // Check if Elementor is installed and activated
    if (did_action('elementor/loaded')) {
        require_once CUSTOMER_SAYS_PLUGIN_DIR . 'includes/elementor/dynamic-tags.php';
    }
}
add_action('plugins_loaded', 'customer_says_elementor_init', 20);

// Plugin activation hook
function customer_says_activate() {
    // Initialize post type
    customer_says_register_post_type();
    // Flush rewrite rules
    flush_rewrite_rules();
    // Fire after activation hook
    do_action('customer_says_after_activation');
}
register_activation_hook(__FILE__, 'customer_says_activate');

// Plugin deactivation hook
function customer_says_deactivate() {
    // Unregister post type
    unregister_post_type('testimoni');
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'customer_says_deactivate');

// Check if Elementor is installed and activated
function customer_says_elementor_notice() {
    global $pagenow;
    
    // Only show notice if we're in the Elementor editor or trying to use Dynamic Tags
    $is_elementor_editor = (isset($_GET['action']) && $_GET['action'] === 'elementor') || 
                          (isset($_GET['elementor-preview']));
    
    $is_testimonial_page = isset($_GET['post_type']) && $_GET['post_type'] === 'testimoni';
    
    if (!did_action('elementor/loaded') && $is_elementor_editor && $is_testimonial_page) {
        ?>
        <div class="notice notice-info is-dismissible">
            <p><?php _e('Customer Says: Untuk menggunakan fitur Dynamic Tags, silakan install dan aktifkan plugin Elementor. Plugin tetap dapat berfungsi tanpa Elementor menggunakan shortcode.', 'customer-says'); ?></p>
            <p><code>[customer_says_form]</code> - <?php _e('untuk menampilkan form testimoni', 'customer-says'); ?></p>
            <p><code>[customer_says_list]</code> - <?php _e('untuk menampilkan daftar testimoni', 'customer-says'); ?></p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'customer_says_elementor_notice');

// Enqueue scripts and styles
function customer_says_enqueue_scripts() {
    // Enqueue form styles
    wp_enqueue_style(
        'customer-says-form',
        CUSTOMER_SAYS_PLUGIN_URL . 'assets/css/form.css',
        array(),
        CUSTOMER_SAYS_VERSION
    );

    // Only load TinyMCE assets on pages with the testimonial form
    global $post;
    if (is_a($post, 'WP_Post') && (
        has_shortcode($post->post_content, 'customer_says_form') || 
        has_shortcode($post->post_content, 'customer_says_list') ||
        is_page_template('templates/template-testimonials.php')
    )) {
        wp_enqueue_editor();
        
        // Enqueue custom scripts
        wp_enqueue_script(
            'customer-says-form',
            CUSTOMER_SAYS_PLUGIN_URL . 'assets/js/form.js',
            array('jquery'),
            CUSTOMER_SAYS_VERSION,
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'customer_says_enqueue_scripts');

// Add custom styles for TinyMCE
function customer_says_add_editor_styles() {
    add_editor_style(CUSTOMER_SAYS_PLUGIN_URL . 'assets/css/form.css');
}
add_action('admin_init', 'customer_says_add_editor_styles');

// Initialize the plugin
function customer_says_init() {
    // Load plugin text domain
    load_plugin_textdomain(
        'customer-says',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
    
    // Initialize post type
    customer_says_register_post_type();
}
add_action('init', 'customer_says_init');

// Add settings link on plugin page
function customer_says_plugin_action_links($links) {
    $settings_link = '<a href="edit.php?post_type=testimoni">' . __('Manage Testimonials', 'customer-says') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'customer_says_plugin_action_links');