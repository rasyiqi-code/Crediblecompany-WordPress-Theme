# Customer Says - WordPress Testimonial Plugin

Plugin WordPress untuk mengelola dan menampilkan testimoni pelanggan dengan mudah dan fleksibel.

## Deskripsi

Customer Says adalah plugin WordPress yang memungkinkan Anda mengelola dan menampilkan testimoni pelanggan dengan cara yang elegan. Plugin ini mendukung custom post type dan dapat diintegrasikan dengan Elementor (opsional).

### Fitur Utama

- ✨ Form submit testimoni yang responsif
- 📱 Tampilan grid dan list yang mobile-friendly
- 🖼️ Dukungan foto profil pelanggan
- ⭐ Sistem rating bintang
- 🎨 Integrasi dengan Elementor (opsional)
- 🔧 Shortcode untuk fleksibilitas maksimal
- 📝 Editor WYSIWYG untuk konten testimoni
- 🌐 Mendukung multi-bahasa

## Persyaratan Sistem

- WordPress 5.2 atau lebih tinggi
- PHP 7.2 atau lebih tinggi
- MySQL 5.6 atau lebih tinggi

## Instalasi

1. Upload folder `customer-says` ke direktori `/wp-content/plugins/`
2. Aktifkan plugin melalui menu 'Plugins' di WordPress
3. Gunakan shortcode untuk menampilkan form atau daftar testimoni

## Penggunaan

### Shortcode Dasar

1. Menampilkan form submit testimoni:
```
[customer_says_form]
```

2. Menampilkan daftar testimoni:
```
[customer_says_list]
```

### Opsi Shortcode untuk Daftar Testimoni

```
[customer_says_list count="10" layout="grid" columns="3" orderby="date" order="DESC"]
```

- `count`: Jumlah testimoni yang ditampilkan (default: 10)
- `layout`: Pilihan tampilan "grid" atau "list" (default: grid)
- `columns`: Jumlah kolom untuk layout grid (1-4, default: 3)
- `orderby`: Pengurutan berdasarkan "date", "title", dll (default: date)
- `order`: Urutan "ASC" atau "DESC" (default: DESC)

### Penggunaan dalam Template PHP

```php
// Menampilkan form
<?php echo customer_says_display_form(); ?>

// Menampilkan daftar testimoni
<?php 
echo customer_says_display_testimonials([
    'count' => 10,
    'layout' => 'grid',
    'columns' => 3
]); 
?>
```

### Integrasi Elementor (Opsional)

Jika Anda menggunakan Elementor, plugin ini menyediakan Dynamic Tags untuk:
- Nama Pelanggan
- Kota
- Profesi
- Rating

## Changelog

### 1.3.0
- Elementor sekarang bersifat opsional
- Menambahkan sistem shortcode yang komprehensif
- Menambahkan template functions untuk penggunaan dalam tema
- Perbaikan tampilan responsif
- Optimasi performa

### 1.2.0
- Penambahan integrasi Elementor
- Perbaikan bug minor

### 1.1.0
- Penambahan fitur rating bintang
- Perbaikan tampilan form

### 1.0.0
- Rilis perdana

## FAQ

### Apakah saya harus menggunakan Elementor?
Tidak, plugin ini dapat berfungsi penuh tanpa Elementor. Anda dapat menggunakan shortcode atau fungsi template untuk menampilkan testimoni.

### Bagaimana cara mengubah tampilan testimoni?
Anda dapat menggunakan CSS kustom atau mengubah template di folder tema Anda.

### Apakah plugin mendukung multi-bahasa?
Ya, plugin ini dapat diterjemahkan dan sudah mendukung sistem translasi WordPress.

## Dukungan

Jika Anda menemukan masalah atau memiliki pertanyaan, silakan buat issue di repositori GitHub atau hubungi kami melalui:

- Website: [crediblemark.com](https://crediblemark.com)
- Email: support@crediblemark.com

## Lisensi

Plugin ini dilisensikan di bawah GPL v2 atau yang lebih baru.

## Credits

Dibuat dengan ❤️ oleh [Rasyiqi](https://crediblemark.com) 