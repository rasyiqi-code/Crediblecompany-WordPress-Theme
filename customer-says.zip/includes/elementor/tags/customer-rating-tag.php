<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_Rating_Tag extends \Elementor\Core\DynamicTags\Data_Tag {

    public function get_name() {
        return 'customer-rating';
    }

    public function get_title() {
        return esc_html__('Rating Customer', 'customer-says');
    }

    public function get_group() {
        return 'customer-says';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function get_value(array $options = []) {
        $post_id = get_the_ID();
        if (get_post_type($post_id) !== 'testimoni') {
            return '';
        }

        $rating = get_post_meta($post_id, '_customer_rating', true);
        if (!empty($rating)) {
            return str_repeat('⭐', intval($rating));
        }
        return '';
    }
} 