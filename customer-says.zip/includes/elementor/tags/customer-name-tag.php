<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_Name_Tag extends \Elementor\Core\DynamicTags\Tag {

    public function get_name() {
        return 'customer-name';
    }

    public function get_title() {
        return esc_html__('Nama Customer', 'customer-says');
    }

    public function get_group() {
        return 'customer-says';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    public function render() {
        $post_id = get_the_ID();
        
        // Only show on testimoni post type
        if (get_post_type($post_id) !== 'testimoni') {
            return;
        }

        $customer_name = get_post_meta($post_id, '_customer_name', true);
        if (!empty($customer_name)) {
            echo wp_kses_post($customer_name);
        }
    }
} 