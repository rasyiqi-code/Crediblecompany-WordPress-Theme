<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_City_Tag extends \Elementor\Core\DynamicTags\Data_Tag {

    public function get_name() {
        return 'customer-city';
    }

    public function get_title() {
        return esc_html__('Kota Customer', 'customer-says');
    }

    public function get_group() {
        return 'customer-says';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function get_value(array $options = []) {
        $post_id = get_the_ID();
        if (get_post_type($post_id) !== 'testimoni') {
            return '';
        }

        $customer_city = get_post_meta($post_id, '_customer_city', true);
        return wp_kses_post($customer_city);
    }
} 