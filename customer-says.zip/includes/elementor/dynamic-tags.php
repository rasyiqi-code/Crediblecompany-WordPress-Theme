<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_Says_Dynamic_Tags {
    
    public function __construct() {
        add_action('elementor/dynamic_tags/register', [$this, 'register_tags']);
    }

    public function register_tags($dynamic_tags) {
        \Elementor\Plugin::$instance->dynamic_tags->register_group(
            'customer-says',
            [
                'title' => esc_html__('Customer Says', 'customer-says')
            ]
        );

        // Include tag files
        foreach ([
            'customer-name-tag',
            'customer-city-tag',
            'customer-profession-tag',
            'customer-rating-tag'
        ] as $tag) {
            require_once(__DIR__ . "/tags/{$tag}.php");
        }

        // Register tags
        $tags = [
            'Customer_Name_Tag',
            'Customer_City_Tag',
            'Customer_Profession_Tag',
            'Customer_Rating_Tag'
        ];

        foreach ($tags as $tag) {
            if (class_exists($tag)) {
                $dynamic_tags->register(new $tag());
            }
        }
    }
}

// Initialize after Elementor loads
add_action('elementor/init', function() {
    new Customer_Says_Dynamic_Tags();
}); 