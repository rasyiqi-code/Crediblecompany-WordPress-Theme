<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display welcome notice with shortcode information
 */
function customer_says_welcome_notice() {
    // Get the activation date
    $activation_date = get_option('customer_says_activation_date');
    
    // Show notice only for 7 days after activation
    if ($activation_date && (time() - $activation_date) > 7 * DAY_IN_SECONDS) {
        return;
    }

    // Don't show if user dismissed the notice
    if (get_user_meta(get_current_user_id(), 'customer_says_welcome_notice_dismissed', true)) {
        return;
    }
    ?>
    <div class="notice notice-info is-dismissible customer-says-welcome-notice">
        <h3><?php _e('🎉 Terima kasih telah menginstall Customer Says!', 'customer-says'); ?></h3>
        
        <p><?php _e('Gunakan shortcode berikut untuk menampilkan testimoni di website Anda:', 'customer-says'); ?></p>
        
        <div class="customer-says-shortcode-info">
            <div class="shortcode-item">
                <code>[customer_says_form]</code>
                <span class="description"><?php _e('Untuk menampilkan form submit testimoni', 'customer-says'); ?></span>
            </div>
            
            <div class="shortcode-item">
                <code>[customer_says_list]</code>
                <span class="description"><?php _e('Untuk menampilkan daftar testimoni', 'customer-says'); ?></span>
            </div>

            <div class="shortcode-item">
                <code>[customer_says_list count="6" layout="grid" columns="3"]</code>
                <span class="description"><?php _e('Contoh penggunaan dengan parameter', 'customer-says'); ?></span>
            </div>
        </div>

        <p>
            <a href="edit.php?post_type=testimoni" class="button button-primary">
                <?php _e('Kelola Testimoni', 'customer-says'); ?>
            </a>
            <a href="https://github.com/username/customer-says#readme" class="button button-secondary" target="_blank">
                <?php _e('Dokumentasi Lengkap', 'customer-says'); ?>
            </a>
        </p>
    </div>

    <style>
        .customer-says-welcome-notice {
            padding: 20px;
        }
        .customer-says-welcome-notice h3 {
            margin-top: 0;
        }
        .customer-says-shortcode-info {
            background: #f8f8f8;
            padding: 15px;
            border-radius: 4px;
            margin: 15px 0;
        }
        .customer-says-shortcode-info .shortcode-item {
            margin-bottom: 10px;
        }
        .customer-says-shortcode-info .shortcode-item:last-child {
            margin-bottom: 0;
        }
        .customer-says-shortcode-info code {
            display: inline-block;
            padding: 5px 10px;
            background: #fff;
            border: 1px solid #ddd;
            margin-right: 10px;
        }
        .customer-says-welcome-notice .button {
            margin-right: 10px;
        }
    </style>

    <script>
    jQuery(document).ready(function($) {
        $(document).on('click', '.customer-says-welcome-notice .notice-dismiss', function() {
            $.ajax({
                url: ajaxurl,
                data: {
                    action: 'customer_says_dismiss_welcome_notice'
                }
            });
        });
    });
    </script>
    <?php
}
add_action('admin_notices', 'customer_says_welcome_notice');

/**
 * Ajax handler to dismiss the welcome notice
 */
function customer_says_dismiss_welcome_notice() {
    update_user_meta(get_current_user_id(), 'customer_says_welcome_notice_dismissed', true);
    wp_die();
}
add_action('wp_ajax_customer_says_dismiss_welcome_notice', 'customer_says_dismiss_welcome_notice');

/**
 * Set activation date when plugin is activated
 */
function customer_says_set_activation_date() {
    if (!get_option('customer_says_activation_date')) {
        update_option('customer_says_activation_date', time());
    }
}
add_action('customer_says_after_activation', 'customer_says_set_activation_date'); 