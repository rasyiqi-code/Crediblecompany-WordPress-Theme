<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register all shortcodes
 */
function customer_says_register_shortcodes() {
    add_shortcode('customer_says_form', 'customer_says_form_shortcode');
    add_shortcode('customer_says_list', 'customer_says_list_shortcode');
}
add_action('init', 'customer_says_register_shortcodes');

/**
 * Shortcode for displaying the testimonial submission form
 */
function customer_says_form_shortcode($atts) {
    // Buffer the output
    ob_start();
    
    // Include the form template
    include CUSTOMER_SAYS_PLUGIN_DIR . 'templates/form-testimoni.php';
    
    // Return the buffered content
    return ob_get_clean();
}

/**
 * Shortcode for displaying testimonials list
 */
function customer_says_list_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count' => 10,
        'orderby' => 'date',
        'order' => 'DESC',
        'layout' => 'grid', // grid or list
        'columns' => 3,     // 1-4 columns for grid layout
    ), $atts);

    // Sanitize attributes
    $count = absint($atts['count']);
    $orderby = sanitize_key($atts['orderby']);
    $order = in_array(strtoupper($atts['order']), array('ASC', 'DESC')) ? strtoupper($atts['order']) : 'DESC';
    $layout = in_array($atts['layout'], array('grid', 'list')) ? $atts['layout'] : 'grid';
    $columns = max(1, min(4, absint($atts['columns'])));

    // Query testimonials
    $args = array(
        'post_type' => 'testimoni',
        'posts_per_page' => $count,
        'orderby' => $orderby,
        'order' => $order,
        'post_status' => 'publish'
    );

    $testimonials = new WP_Query($args);
    
    // Buffer the output
    ob_start();

    if ($testimonials->have_posts()) {
        // Add layout class
        $wrapper_class = 'customer-says-testimonials';
        $wrapper_class .= ' layout-' . $layout;
        if ($layout === 'grid') {
            $wrapper_class .= ' columns-' . $columns;
        }
        
        echo '<div class="' . esc_attr($wrapper_class) . '">';
        
        while ($testimonials->have_posts()) {
            $testimonials->the_post();
            include CUSTOMER_SAYS_PLUGIN_DIR . 'templates/content-testimoni.php';
        }
        
        echo '</div>';
    } else {
        echo '<p class="customer-says-no-testimonials">';
        _e('Belum ada testimoni.', 'customer-says');
        echo '</p>';
    }

    wp_reset_postdata();
    
    return ob_get_clean();
} 