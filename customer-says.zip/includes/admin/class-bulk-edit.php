<?php
/**
 * Bulk Edit Rating Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Customer_Says_Bulk_Edit {
    
    public function __construct() {
        // Menambahkan kolom rating ke quick edit dan bulk edit
        add_action('bulk_edit_custom_box', array($this, 'add_bulk_edit_fields'), 10, 2);
        add_action('quick_edit_custom_box', array($this, 'add_bulk_edit_fields'), 10, 2);
        
        // Menambahkan script untuk bulk edit
        add_action('admin_footer', array($this, 'add_bulk_edit_script'));
        
        // Handle save bulk edit
        add_action('save_post', array($this, 'save_bulk_edit_rating'), 10, 2);
        add_action('wp_ajax_save_bulk_edit_customer_says', array($this, 'save_bulk_edit_rating_callback'));
    }

    /**
     * Menambahkan field rating ke form bulk edit
     */
    public function add_bulk_edit_fields($column_name, $post_type) {
        if ($post_type !== 'testimoni' || $column_name !== 'rating') {
            return;
        }
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label class="inline-edit-group">
                    <span class="title"><?php _e('Rating', 'customer-says'); ?></span>
                    <select name="customer_rating">
                        <option value=""><?php _e('— No Change —', 'customer-says'); ?></option>
                        <?php for ($i = 1; $i <= 5; $i++) : ?>
                            <option value="<?php echo $i; ?>">
                                <?php echo str_repeat('⭐', $i); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </label>
            </div>
        </fieldset>
        <?php
    }

    /**
     * Menambahkan script untuk bulk edit
     */
    public function add_bulk_edit_script() {
        global $post_type;
        if ($post_type !== 'testimoni') {
            return;
        }
        ?>
        <script type="text/javascript">
            jQuery(function($) {
                // Bulk Edit
                $('#bulk_edit').on('click', function() {
                    // Get the selected rating
                    var rating = $('select[name="customer_rating"]').val();
                    
                    // Get the IDs of selected posts
                    var postIds = [];
                    $('input[name="post[]"]:checked').each(function() {
                        postIds.push($(this).val());
                    });
                    
                    // Make ajax request
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        async: false,
                        cache: false,
                        data: {
                            action: 'save_bulk_edit_customer_says',
                            post_ids: postIds,
                            rating: rating,
                            nonce: '<?php echo wp_create_nonce('customer-says-bulk-edit'); ?>'
                        }
                    });
                });

                // Quick Edit
                $('.editinline').on('click', function() {
                    var postId = $(this).closest('tr').attr('id').replace('post-', '');
                    var rating = $('#customer_rating_' + postId).val();
                    
                    $('select[name="customer_rating"]').val(rating);
                });
            });
        </script>
        <?php
    }

    /**
     * Handle save bulk edit melalui AJAX
     */
    public function save_bulk_edit_rating_callback() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'customer-says-bulk-edit')) {
            wp_die('Invalid nonce');
        }

        // Check permissions
        if (!current_user_can('edit_posts')) {
            wp_die('Insufficient permissions');
        }

        $post_ids = isset($_POST['post_ids']) ? $_POST['post_ids'] : array();
        $rating = isset($_POST['rating']) ? absint($_POST['rating']) : '';

        if (!empty($rating) && !empty($post_ids)) {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_customer_rating', $rating);
            }
        }

        wp_die();
    }

    /**
     * Handle save untuk quick edit
     */
    public function save_bulk_edit_rating($post_id, $post) {
        // Skip if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Check if this is a quick edit
        if (!isset($_POST['_inline_edit']) || !wp_verify_nonce($_POST['_inline_edit'], 'inlineeditnonce')) {
            return;
        }

        if (isset($_POST['customer_rating'])) {
            $rating = absint($_POST['customer_rating']);
            if ($rating >= 1 && $rating <= 5) {
                update_post_meta($post_id, '_customer_rating', $rating);
            }
        }
    }
}

// Initialize the class
new Customer_Says_Bulk_Edit(); 