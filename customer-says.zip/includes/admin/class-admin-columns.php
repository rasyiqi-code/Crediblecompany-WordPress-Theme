<?php
/**
 * Admin Columns Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Customer_Says_Admin_Columns {
    
    public function __construct() {
        add_filter('manage_testimoni_posts_columns', array($this, 'add_columns'));
        add_action('manage_testimoni_posts_custom_column', array($this, 'render_columns'), 10, 2);
        add_filter('manage_edit-testimoni_sortable_columns', array($this, 'sortable_columns'));
    }

    /**
     * Menambahkan kolom baru
     */
    public function add_columns($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            if ($key === 'title') {
                $new_columns[$key] = $value;
                $new_columns['customer_name'] = __('Nama', 'customer-says');
                $new_columns['customer_profession'] = __('Profesi', 'customer-says');
                $new_columns['customer_city'] = __('Kota', 'customer-says');
                $new_columns['rating'] = __('Rating', 'customer-says');
            } else {
                $new_columns[$key] = $value;
            }
        }
        
        return $new_columns;
    }

    /**
     * Render isi kolom
     */
    public function render_columns($column, $post_id) {
        switch ($column) {
            case 'customer_name':
                echo esc_html(get_post_meta($post_id, '_customer_name', true));
                break;
                
            case 'customer_profession':
                echo esc_html(get_post_meta($post_id, '_customer_profession', true));
                break;
                
            case 'customer_city':
                echo esc_html(get_post_meta($post_id, '_customer_city', true));
                break;
                
            case 'rating':
                $rating = get_post_meta($post_id, '_customer_rating', true);
                if ($rating) {
                    echo str_repeat('⭐', intval($rating));
                    // Hidden input untuk quick edit
                    echo '<input type="hidden" id="customer_rating_' . $post_id . '" value="' . esc_attr($rating) . '" />';
                }
                break;
        }
    }

    /**
     * Menambahkan kolom yang bisa di-sort
     */
    public function sortable_columns($columns) {
        $columns['rating'] = 'rating';
        $columns['customer_name'] = 'customer_name';
        $columns['customer_profession'] = 'customer_profession';
        $columns['customer_city'] = 'customer_city';
        return $columns;
    }
}

// Initialize the class
new Customer_Says_Admin_Columns(); 