<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get customer rating as stars
 */
function customer_says_get_rating_stars($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $rating = get_post_meta($post_id, '_customer_rating', true);
    if (!$rating) {
        return '';
    }
    
    return str_repeat('⭐', intval($rating));
}

/**
 * Get customer meta data
 */
function customer_says_get_customer_meta($key, $post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    return get_post_meta($post_id, '_customer_' . $key, true);
}

/**
 * Display testimonials in a template
 */
function customer_says_display_testimonials($args = array()) {
    $default_args = array(
        'count' => 10,
        'orderby' => 'date',
        'order' => 'DESC',
        'layout' => 'grid',
        'columns' => 3
    );
    
    $args = wp_parse_args($args, $default_args);
    
    return do_shortcode(
        sprintf(
            '[customer_says_list count="%d" orderby="%s" order="%s" layout="%s" columns="%d"]',
            $args['count'],
            $args['orderby'],
            $args['order'],
            $args['layout'],
            $args['columns']
        )
    );
}

/**
 * Display testimonial submission form in a template
 */
function customer_says_display_form() {
    return do_shortcode('[customer_says_form]');
}

/**
 * Check if current page is testimonial page
 */
function customer_says_is_testimonial_page() {
    return (
        is_post_type_archive('testimoni') ||
        is_singular('testimoni') ||
        is_page_template('templates/template-testimonials.php') ||
        (is_page() && has_shortcode(get_post()->post_content, 'customer_says_form')) ||
        (is_page() && has_shortcode(get_post()->post_content, 'customer_says_list'))
    );
} 