<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_Says_Metabox {
    
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_meta_boxes'));
        
        // Add ACF compatibility check
        add_action('admin_notices', array($this, 'check_acf_compatibility'));
    }

    public function check_acf_compatibility() {
        // Only show on testimonial post type
        if (!isset($_GET['post_type']) || $_GET['post_type'] !== 'testimoni') {
            return;
        }

        // Check if ACF was previously used
        $has_acf_data = get_option('customer_says_has_acf_data');
        
        if ($has_acf_data && !class_exists('ACF')) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <?php _e('Customer Says: Data testimonial sebelumnya menggunakan Advanced Custom Fields (ACF). Data telah dimigrasi ke sistem metabox bawaan plugin.', 'customer-says'); ?>
                </p>
                <p>
                    <?php _e('Jika Anda ingin kembali menggunakan ACF, silakan aktifkan kembali plugin ACF.', 'customer-says'); ?>
                </p>
            </div>
            <?php
        }
    }

    public function add_meta_boxes() {
        add_meta_box(
            'customer_says_details',
            __('Informasi Tambahan', 'customer-says'),
            array($this, 'render_meta_box'),
            'testimoni',
            'normal',
            'high'
        );
    }

    public function render_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('customer_says_meta_box', 'customer_says_meta_box_nonce');

        // Get saved values
        $customer_name = get_post_meta($post->ID, '_customer_name', true);
        $customer_city = get_post_meta($post->ID, '_customer_city', true);
        $customer_profession = get_post_meta($post->ID, '_customer_profession', true);
        $customer_rating = get_post_meta($post->ID, '_customer_rating', true);

        // Check for ACF data and migrate if needed
        if (!$customer_name && class_exists('ACF')) {
            $acf_name = get_field('customer_name', $post->ID);
            $acf_city = get_field('customer_city', $post->ID);
            $acf_profession = get_field('customer_profession', $post->ID);
            $acf_rating = get_field('customer_rating', $post->ID);

            if ($acf_name || $acf_city || $acf_profession || $acf_rating) {
                // Migrate ACF data to post meta
                update_post_meta($post->ID, '_customer_name', $acf_name);
                update_post_meta($post->ID, '_customer_city', $acf_city);
                update_post_meta($post->ID, '_customer_profession', $acf_profession);
                update_post_meta($post->ID, '_customer_rating', $acf_rating);

                // Update the variables with migrated data
                $customer_name = $acf_name;
                $customer_city = $acf_city;
                $customer_profession = $acf_profession;
                $customer_rating = $acf_rating;

                // Mark that we have ACF data
                update_option('customer_says_has_acf_data', true);
            }
        }
        ?>
        <div class="customer-says-meta-box">
            <p>
                <label for="customer_name"><?php _e('Nama Lengkap:', 'customer-says'); ?></label>
                <input type="text" id="customer_name" name="customer_name" value="<?php echo esc_attr($customer_name); ?>" class="widefat">
            </p>
            
            <p>
                <label for="customer_city"><?php _e('Kota:', 'customer-says'); ?></label>
                <input type="text" id="customer_city" name="customer_city" value="<?php echo esc_attr($customer_city); ?>" class="widefat">
            </p>
            
            <p>
                <label for="customer_profession"><?php _e('Profesi:', 'customer-says'); ?></label>
                <input type="text" id="customer_profession" name="customer_profession" value="<?php echo esc_attr($customer_profession); ?>" class="widefat">
            </p>
            
            <p>
                <label for="customer_rating"><?php _e('Rating:', 'customer-says'); ?></label>
                <select id="customer_rating" name="customer_rating" class="widefat">
                    <option value=""><?php _e('Pilih Rating', 'customer-says'); ?></option>
                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                        <option value="<?php echo $i; ?>" <?php selected($customer_rating, $i); ?>>
                            <?php echo str_repeat('⭐', $i); ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </p>
        </div>
        <style>
            .customer-says-meta-box label {
                display: block;
                font-weight: 600;
                margin-bottom: 5px;
            }
            .customer-says-meta-box p {
                margin-bottom: 15px;
            }
        </style>
        <?php
    }

    public function save_meta_boxes($post_id) {
        // Check if our nonce is set
        if (!isset($_POST['customer_says_meta_box_nonce'])) {
            return;
        }

        // Verify that the nonce is valid
        if (!wp_verify_nonce($_POST['customer_says_meta_box_nonce'], 'customer_says_meta_box')) {
            return;
        }

        // If this is an autosave, our form has not been submitted, so we don't want to do anything
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check the user's permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Save the meta box data
        $fields = array(
            'customer_name',
            'customer_city',
            'customer_profession',
            'customer_rating'
        );

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta(
                    $post_id,
                    '_' . $field,
                    sanitize_text_field($_POST[$field])
                );
            }
        }
    }
}

new Customer_Says_Metabox(); 