<?php
if (!defined('ABSPATH')) {
    exit;
}

class Customer_Says_Form_Handler {
    
    public function __construct() {
        add_action('init', array($this, 'handle_form_submission'));
        add_shortcode('customer_says_form', array($this, 'render_form'));
        add_action('wp_ajax_customer_says_submit', array($this, 'ajax_form_submission'));
        add_action('wp_ajax_nopriv_customer_says_submit', array($this, 'ajax_form_submission'));
    }

    public function handle_form_submission() {
        if (!isset($_POST['submit_testimonial']) || !isset($_POST['customer_says_nonce'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['customer_says_nonce'], 'customer_says_form_nonce')) {
            wp_die(__('Invalid nonce specified', 'customer-says'));
        }

        // Validate required fields
        $required_fields = array(
            'testimonial_title',
            'customer_name',
            'customer_city',
            'customer_profession',
            'customer_rating',
            'testimonial_content'
        );

        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                wp_die(__('Mohon lengkapi semua field yang wajib diisi', 'customer-says'));
            }
        }

        // Sanitize input
        $testimonial_title = sanitize_text_field($_POST['testimonial_title']);
        $customer_name = sanitize_text_field($_POST['customer_name']);
        $customer_email = !empty($_POST['customer_email']) ? sanitize_email($_POST['customer_email']) : '';
        $customer_city = sanitize_text_field($_POST['customer_city']);
        $customer_profession = sanitize_text_field($_POST['customer_profession']);
        $customer_rating = absint($_POST['customer_rating']);
        $testimonial_content = wp_kses_post($_POST['testimonial_content']);

        // Validate rating
        if ($customer_rating < 1 || $customer_rating > 5) {
            wp_die(__('Rating tidak valid', 'customer-says'));
        }

        // Validate email if provided
        if (!empty($customer_email) && !is_email($customer_email)) {
            wp_die(__('Format email tidak valid', 'customer-says'));
        }

        // Validasi upload foto profil wajib
        if (empty($_FILES['customer_photo']['name'])) {
            wp_die(__('Mohon upload foto profil Anda (wajib diisi)', 'customer-says'));
        }

        // Create post object
        $testimonial_data = array(
            'post_title'   => $testimonial_title,
            'post_content' => $testimonial_content,
            'post_status'  => 'pending',
            'post_type'    => 'testimoni'
        );

        // Insert the post into the database
        $post_id = wp_insert_post($testimonial_data);

        if (!is_wp_error($post_id)) {
            // Save meta data
            $meta_fields = array(
                '_customer_name' => $customer_name,
                '_customer_city' => $customer_city,
                '_customer_profession' => $customer_profession,
                '_customer_rating' => $customer_rating
            );

            // Only save email if provided
            if (!empty($customer_email)) {
                $meta_fields['_customer_email'] = $customer_email;
            }

            foreach ($meta_fields as $key => $value) {
                update_post_meta($post_id, $key, $value);
            }

            // Handle file upload
            if (!empty($_FILES['customer_photo']['name'])) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');

                $attachment_id = media_handle_upload('customer_photo', $post_id);
                if (!is_wp_error($attachment_id)) {
                    set_post_thumbnail($post_id, $attachment_id);
                }
            }

            // Redirect with success message
            wp_redirect(add_query_arg('testimonial_submitted', 'true', wp_get_referer()));
            exit;
        }
    }

    public function render_form() {
        ob_start();
        
        // Show success message if testimonial was submitted
        if (isset($_GET['testimonial_submitted']) && $_GET['testimonial_submitted'] === 'true') {
            echo '<div class="customer-says-success">';
            _e('Terima kasih! Testimoni Anda telah berhasil dikirim dan sedang menunggu persetujuan.', 'customer-says');
            echo '</div>';
        }

        include CUSTOMER_SAYS_PLUGIN_DIR . 'templates/form-testimoni.php';
        return ob_get_clean();
    }

    /**
     * Handler AJAX untuk submit testimoni via AJAX (tanpa reload)
     *
     * @return void
     */
    public function ajax_form_submission() {
        // Cek nonce
        if (!isset($_POST['customer_says_nonce']) || !wp_verify_nonce($_POST['customer_says_nonce'], 'customer_says_form_nonce')) {
            wp_send_json_error(['message' => __('Nonce tidak valid', 'customer-says')]);
        }

        // Validasi field wajib
        $required_fields = array(
            'testimonial_title',
            'customer_name',
            'customer_city',
            'customer_profession',
            'customer_rating',
            'testimonial_content'
        );
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error(['message' => __('Mohon lengkapi semua field yang wajib diisi', 'customer-says')]);
            }
        }

        // Validasi upload foto profil wajib
        if (empty($_FILES['customer_photo']['name'])) {
            wp_send_json_error(['message' => __('Mohon upload foto profil Anda (wajib diisi)', 'customer-says')]);
        }

        // Sanitasi input
        $testimonial_title = sanitize_text_field($_POST['testimonial_title']);
        $customer_name = sanitize_text_field($_POST['customer_name']);
        $customer_email = !empty($_POST['customer_email']) ? sanitize_email($_POST['customer_email']) : '';
        $customer_city = sanitize_text_field($_POST['customer_city']);
        $customer_profession = sanitize_text_field($_POST['customer_profession']);
        $customer_rating = absint($_POST['customer_rating']);
        $testimonial_content = wp_kses_post($_POST['testimonial_content']);

        // Validasi rating
        if ($customer_rating < 1 || $customer_rating > 5) {
            wp_send_json_error(['message' => __('Rating tidak valid', 'customer-says')]);
        }
        // Validasi email jika diisi
        if (!empty($customer_email) && !is_email($customer_email)) {
            wp_send_json_error(['message' => __('Format email tidak valid', 'customer-says')]);
        }

        // Buat post testimoni
        $testimonial_data = array(
            'post_title'   => $testimonial_title,
            'post_content' => $testimonial_content,
            'post_status'  => 'pending',
            'post_type'    => 'testimoni'
        );
        $post_id = wp_insert_post($testimonial_data);
        if (is_wp_error($post_id)) {
            wp_send_json_error(['message' => __('Gagal menyimpan testimoni', 'customer-says')]);
        }

        // Simpan meta data
        $meta_fields = array(
            '_customer_name' => $customer_name,
            '_customer_city' => $customer_city,
            '_customer_profession' => $customer_profession,
            '_customer_rating' => $customer_rating
        );
        if (!empty($customer_email)) {
            $meta_fields['_customer_email'] = $customer_email;
        }
        foreach ($meta_fields as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }

        // Handle upload foto profil
        if (!empty($_FILES['customer_photo']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $attachment_id = media_handle_upload('customer_photo', $post_id);
            if (!is_wp_error($attachment_id)) {
                set_post_thumbnail($post_id, $attachment_id);
            }
        }

        // Sukses
        wp_send_json_success(['message' => __('Terima kasih! Testimoni Anda telah berhasil dikirim dan sedang menunggu persetujuan.', 'customer-says')]);
    }
}

new Customer_Says_Form_Handler(); 