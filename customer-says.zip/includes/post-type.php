<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Register the testimoni post type
 */
function customer_says_register_post_type() {
    $labels = array(
        'name'               => _x('Testimoni', 'post type general name', 'customer-says'),
        'singular_name'      => _x('Testimoni', 'post type singular name', 'customer-says'),
        'menu_name'          => _x('Testimoni', 'admin menu', 'customer-says'),
        'name_admin_bar'     => _x('Testimoni', 'add new on admin bar', 'customer-says'),
        'add_new'            => _x('Tambah Baru', 'testimonial', 'customer-says'),
        'add_new_item'       => __('Tambah Testimoni Baru', 'customer-says'),
        'new_item'           => __('Testimoni Baru', 'customer-says'),
        'edit_item'          => __('Edit Testimoni', 'customer-says'),
        'view_item'          => __('Lihat Testimoni', 'customer-says'),
        'all_items'          => __('Semua Testimoni', 'customer-says'),
        'search_items'       => __('Cari Testimoni', 'customer-says'),
        'parent_item_colon'  => __('Testimoni Induk:', 'customer-says'),
        'not_found'          => __('Tidak ada testimoni ditemukan.', 'customer-says'),
        'not_found_in_trash' => __('Tidak ada testimoni di tong sampah.', 'customer-says'),
        'featured_image'     => __('Foto Profil', 'customer-says'),
        'set_featured_image' => __('Atur foto profil', 'customer-says'),
        'remove_featured_image' => __('Hapus foto profil', 'customer-says'),
        'use_featured_image' => __('Gunakan sebagai foto profil', 'customer-says')
    );

    $args = array(
        'labels'             => $labels,
        'description'        => __('Testimoni dan ulasan pelanggan', 'customer-says'),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'testimoni'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt',
            'custom-fields'
        ),
        'menu_icon'          => 'dashicons-format-quote',
        'show_in_rest'       => true // Enable Gutenberg editor
    );

    register_post_type('testimoni', $args);
} 