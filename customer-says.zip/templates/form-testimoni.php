<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="customer-says-form-wrapper">
    <form id="customer-says-form" class="customer-says-form" method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('customer_says_form_nonce', 'customer_says_nonce'); ?>

        <div class="photo-upload-wrapper">
            <div class="photo-preview">
                <img src="<?php echo CUSTOMER_SAYS_PLUGIN_URL . 'assets/images/default-avatar.png'; ?>" 
                     alt="<?php _e('Preview', 'customer-says'); ?>" 
                     id="photo-preview"
                     class="default-preview">
            </div>
            <div class="photo-input">
                <label for="customer_photo"><?php _e('Foto Profil', 'customer-says'); ?></label>
                <input type="file" 
                       id="customer_photo" 
                       name="customer_photo" 
                       accept="image/*" 
                       class="photo-input-field"
                       data-default="<?php echo CUSTOMER_SAYS_PLUGIN_URL . 'assets/images/default-avatar.png'; ?>"
                       required>
                <small class="photo-help"><?php _e('Upload foto profil Anda (wajib diisi)', 'customer-says'); ?></small>
            </div>
        </div>

        <div class="form-group">
            <label for="testimonial_title"><?php _e('Judul Testimoni', 'customer-says'); ?> <span class="required">*</span></label>
            <input type="text" 
                   id="testimonial_title" 
                   name="testimonial_title" 
                   required 
                   placeholder="<?php _e('Contoh: Pengalaman Luar Biasa', 'customer-says'); ?>">
            <small class="field-help"><?php _e('Berikan judul yang menggambarkan testimoni Anda', 'customer-says'); ?></small>
        </div>
        
        <div class="form-group">
            <label for="customer_name"><?php _e('Nama Lengkap', 'customer-says'); ?> <span class="required">*</span></label>
            <input type="text" id="customer_name" name="customer_name" required>
        </div>

        <div class="form-group">
            <label for="customer_email"><?php _e('Email', 'customer-says'); ?></label>
            <input type="email" id="customer_email" name="customer_email">
            <small class="field-help"><?php _e('Email Anda akan disimpan secara privat', 'customer-says'); ?></small>
        </div>

        <div class="form-group">
            <label for="customer_city"><?php _e('Kota', 'customer-says'); ?> <span class="required">*</span></label>
            <input type="text" id="customer_city" name="customer_city" required>
        </div>

        <div class="form-group">
            <label for="customer_profession"><?php _e('Profesi', 'customer-says'); ?> <span class="required">*</span></label>
            <input type="text" id="customer_profession" name="customer_profession" required>
        </div>

        <div class="form-group">
            <label for="customer_rating"><?php _e('Rating', 'customer-says'); ?> <span class="required">*</span></label>
            <select id="customer_rating" name="customer_rating" required>
                <option value=""><?php _e('Pilih Rating', 'customer-says'); ?></option>
                <?php for ($i = 1; $i <= 5; $i++) : ?>
                    <option value="<?php echo $i; ?>"><?php echo str_repeat('⭐', $i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="testimonial_content"><?php _e('Testimoni', 'customer-says'); ?> <span class="required">*</span></label>
            <?php
            wp_editor(
                '', // initial content
                'testimonial_content', // ID
                array(
                    'media_buttons' => false, // hide media button
                    'textarea_name' => 'testimonial_content',
                    'textarea_rows' => 5,
                    'teeny' => true, // use minimal editor configuration
                    'quicktags' => false, // disable HTML editor
                    'tinymce' => array(
                        'toolbar1' => 'bold,italic,underline,bullist,numlist,alignleft,aligncenter,alignright',
                        'toolbar2' => '',
                    ),
                )
            );
            ?>
        </div>

        <div class="form-group">
            <button type="submit" name="submit_testimonial" class="submit-testimonial">
                <?php _e('Kirim Testimoni', 'customer-says'); ?>
            </button>
        </div>
    </form>
</div>

<div id="customer-says-modal" class="customer-says-modal" style="display:none;">
    <div class="customer-says-modal-content">
        <span class="customer-says-modal-close">&times;</span>
        <div class="customer-says-modal-message"></div>
    </div>
</div> 