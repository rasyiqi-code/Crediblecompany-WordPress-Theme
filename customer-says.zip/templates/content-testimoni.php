<?php
if (!defined('ABSPATH')) {
    exit;
}

$customer_name = get_post_meta(get_the_ID(), '_customer_name', true);
$customer_city = get_post_meta(get_the_ID(), '_customer_city', true);
$customer_profession = get_post_meta(get_the_ID(), '_customer_profession', true);
$customer_rating = get_post_meta(get_the_ID(), '_customer_rating', true);
?>

<div class="customer-says-item">
    <?php if (has_post_thumbnail()) : ?>
        <div class="customer-says-photo">
            <?php the_post_thumbnail('thumbnail', array('class' => 'customer-photo')); ?>
        </div>
    <?php endif; ?>

    <div class="customer-says-content">
        <?php if ($customer_rating) : ?>
            <div class="customer-says-rating">
                <?php echo str_repeat('⭐', intval($customer_rating)); ?>
            </div>
        <?php endif; ?>

        <div class="customer-says-text">
            <?php the_content(); ?>
        </div>

        <div class="customer-says-meta">
            <?php if ($customer_name) : ?>
                <h4 class="customer-says-name"><?php echo esc_html($customer_name); ?></h4>
            <?php endif; ?>

            <div class="customer-says-details">
                <?php if ($customer_profession) : ?>
                    <span class="customer-says-profession"><?php echo esc_html($customer_profession); ?></span>
                <?php endif; ?>

                <?php if ($customer_city) : ?>
                    <span class="customer-says-city"><?php echo esc_html($customer_city); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> 